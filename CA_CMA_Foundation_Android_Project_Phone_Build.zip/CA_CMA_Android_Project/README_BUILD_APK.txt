FOUNDATION STUDY HUB — ANDROID PROJECT

This is an Android Studio project that wraps your uploaded CA + CMA Foundation
study website in an Android WebView app. Your uploaded icon is included.

BUILD THE APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted
   CA_CMA_Android_Project folder.
4. Allow Gradle sync and install Android SDK Platform 35 if Android Studio asks.
5. Wait for sync to finish.
6. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. When the build completes, choose "locate" in the notification.
   The APK will be under app/build/outputs/apk/debug/app-debug.apk.
8. Transfer that APK to your Android phone and install it.
   Android may ask you to allow installation from that file manager.

NOTES
- This ZIP is Android source project, NOT a prebuilt APK.
- Building requires Android Studio, Android SDK Platform 35, and JDK 17.
- The app opens the included index.html locally; internet is not needed
  for the study dashboard itself.
- Study progress is stored locally in the app's WebView storage.
- This is a debug APK build path. A signed release APK needs a signing key.

PHONE-ONLY BUILD OPTION (GitHub Actions)
1. On your phone, sign in to GitHub in Chrome and create a new public or private repository.
2. Extract this ZIP on your phone.
3. In the repository, use Add file > Upload files. Upload the project contents,
   including the hidden .github/workflows/build-apk.yml file. If your phone's
   upload picker hides hidden folders, use the GitHub web interface's desktop
   site or upload the workflow file separately by creating .github/workflows/build-apk.yml.
4. Open the repository's Actions tab. Run "Build Foundation Study Hub APK"
   using Run workflow (or push/upload to main to trigger it).
5. When the workflow finishes successfully, open its run page and download
   the "Foundation-Study-Hub-APK" artifact.
6. Extract the downloaded artifact ZIP; install app-debug.apk on your phone.

GitHub Actions builds the APK in the cloud; this avoids needing a laptop.
You need a GitHub account and internet access. The first-time upload of the
project may be easier with Chrome's Desktop site enabled.
